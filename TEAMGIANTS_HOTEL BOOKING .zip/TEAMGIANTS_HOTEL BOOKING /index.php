<?php 
include_once("storedata/storedata.html");
?>